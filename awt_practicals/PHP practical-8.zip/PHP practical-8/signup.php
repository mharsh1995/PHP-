<?php
include_once('config.php');

if($_SERVER['REQUEST_METHOD']=="POST"){
 
 $Name=isset($_POST["Name"]) ? mysqli_real_escape_string($conn,$_POST["Name"]) :"";
 $Email=isset($_POST["Email"]) ? mysqli_real_escape_string($conn,$_POST["Email"]) :"";
 $Password=isset($_POST["Password"]) ? mysqli_real_escape_string($conn,$_POST["Password"]) :"";
 $Status=isset($_POST["Status"]) ? mysqli_real_escape_string($conn,$_POST["Status"]) :"";
 
 $sql="INSERT INTO test VALUES ('1','$Name','$Email','$Password','$Status')";
 $qur=mysqli_query($conn,$sql);
 
 if($qur){
  $json=array("Status"=>1,"msg"=>"Done user added!");
}else{
	$json=array("Status"=>0,"msg"=>"Error adding user!");
}
}
 else{
   $json=array("Status"=>0,"msg"=>"Request method not accepted!");
}
@mysqli_close($conn);

header('Content-type:application/json');
echo json_encode($json);

?>