<?php
include_once('config.php');
 
 $UID=isset($_GET["ID"]) ? mysqli_real_escape_string($conn,$_GET["ID"]) :"";
 
 if(!empty($UID))
 	{

 	$qur=mysqli_query($conn,"select Name,Email,Status from test where ID='$UID'");
 	$result=array();

 	while($r = mysqli_fetch_array($qur))
 	{
 		extract($r);
 		$result[]=array("Name" => $Name,"Email" => $Email,"Status" => $Status);
 	}
   
   			$json=array("Status"=>1,"info" => $result);

	}

      else{
	          $json=array("Status"=>0,"msg"=>"User ID not defined!");
          }

@mysqli_close($conn);

header('Content-type:application/json');
echo json_encode($json);
?>