<?php
include_once('config.php');

if($_SERVER['REQUEST_METHOD']=="PUT"){
 
 $UID=isset($_SERVER['HTTP_ID']) ? mysqli_real_escape_string($conn,$_SERVER['HTTP_ID']) :"";
 $status=isset($_SERVER['HTTP_Status']) ? mysqli_real_escape_string($conn,$_SERVER['HTTP_Status']) :"";
 
 if(!empty($UID)){

 	$qur=mysqli_query($conn,"UPDATE test set Status = '$status' where ID='$UID'");
if($qur){

	 $json=array("Status"=>1,"msg"=>"Status updated!");
          }
     else{
     	 $json=array("Status"=>0,"msg"=>"Error updated status!");
          }
     } 
     else{
     	 $json=array("Status"=>0,"msg"=>"User ID not defined!");
          }
   }
   else{
    $json=array("Status"=>0,"msg"=>"User ID not defined!");
          }
@mysqli_close($conn);

header('Content-type:application/json');
echo json_encode($json);

?>