<?php
	//	addcslashes() : 
	$str = "Hello, my name is Kai Jim.";
	echo $str."<br />";
	echo addcslashes($str,'m')."<br />";
	echo addcslashes($str,'K')."<br />";
	/* Output : 
				Hello, my name is Kai Jim.
				Hello, \my na\me is Kai Ji\m.
				Hello, my name is \Kai Jim.
	*/
?>

<?php
	//	chunk_split() : 
	$str = "Hello world!";
	echo chunk_split($str,1,".");
	// Output :  H.e.l.l.o. .w.o.r.l.d.!.
?>

<?php
	// str_ireplace() :
	echo str_ireplace("WORLD","Peter","Hello world!");
	// Output : Hello Peter!
?>

<?php
	// str_pad() :
	$str = "Hello World";
	echo str_pad($str,20,".");
	// Output : Hello World.........
?>

<?php
	// str_split() :
	print_r(str_split("Hello"));
	// Output : Array([0] => H [1] => e [2] => l [3] => l [4] => o)
?>

<?php
	// str_split() :
	print_r(str_split("Hello",3));
	// Output : Array([0] => Hel [1] => lo)
?>

<?php
	// str_word_count() :
	echo str_word_count("Hello world!");
	// Output : 2
?>


<?php
	// strcmp() : 
	echo strcmp("Hello world!","Hello world!");
	// Output : 0
?>

<?php
	// stripcslashes() : 
	echo stripcslashes("Hello, \my na\me is Kai Ji\m.");
	// Output : Hello, my name is Kai Jim.
?>

<?php
	// strncasecmp() :
	echo strncasecmp("Hello world!","hello earth!",6);
	// Output : 0
?>

<?php
	// strpbrk() :
	echo strpbrk("Hello world!","oe");
	// Output : ello world!
?>

<?php
	// strpos() :
	echo strpos("Hello world!","wo");
	// Output : 6
?>

<?php
	// strstr() :
	echo strstr("Hello world!","world");
	// Output : world!
?>

<?php
	$string = "Hello world. Beautiful day today.";
	$token = strtok($string, " ");

	while ($token != false){
		  echo "$token<br />";
		  $token = strtok(" ");
	  } 
	/* Output :
			Hello
			world.
			Beautiful
			day
			today.
	*/
?>

<?php
	// substr() :
	echo substr("Hello world!",6,5);
	// Output : world
?>

<?php
	// substr_compare() :
	echo substr_compare("Hello world","WORLD",6,TRUE);
	// Output : 0
?>

<?php
	// substr_count():
	echo substr_count("Hello world. The world is nice","world");
	// Output : 2
?>









