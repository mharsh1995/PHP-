<?php	
	/*  array_change_key_case() : 
		The array_change_key_case() function returns an array with all array KEYS in lower case or upper case.
	*/
	$a=array("a"=>"Cat","b"=>"Dog","c"=>"Horse");
	print_r(array_change_key_case($a,CASE_UPPER));

	// Output = Array ( [A] => Cat [B] => Dog [C] => Horse ) 
?>


<?php
	/* array_chunk() : 
		The array_chunk() function splits an array into chunks of new arrays.
	*/
	$a=array("a"=>"Cat","b"=>"Dog","c"=>"Horse","d"=>"Cow");
	print_r(array_chunk($a,2));

	//Output = Array ( [A] => Cat [B] => Bird [C] => Horse )
?>

<?php
	/* array_combine() :
		The array_combine() function creates an array by combining two other arrays, where the first array is the keys, and the other array is the values.
	*/ 
	$a1=array("a","b","c","d");
	$a2=array("Cat","Dog","Horse","Cow");
	print_r(array_combine($a1,$a2));

	//Output = Array ( [a] => Cat [b] => Dog [c] => Horse [d] => Cow )
?>


<?php
	/* implode() : 
		The implode() function returns a string from the elements of an array.
	*/
	$arr = array('Hello','World!','Day!');
	echo implode(" ",$arr);

	//Ouput = Hello World! Day!
?>

<?php
	/* explode() : 
	 	The explode() function breaks a string into an array.
	*/
		$str = "Hello world. It's a beautiful day.";
		print_r (explode(" ",$str));

	// Ouput = Array ([0] => Hello ,[1] => world. ,[2] => It's , [3] => a ,[4] => beautiful,[5] =>day.	
?>


<?php
	/* array_diff() : 
		The array_diff() function compares two or more arrays, and returns an array with the keys and values from the first array, only if the value is not present in any of the other arrays.
	*/

	$array1 = array("a" => "green" , "red" , "blue" , "red");
	$array2 = array("b" => "green" , "yellow" , "red");
	$result = array_diff($array1, $array2);
	print_r($result);

	//Output = Array([1] => blue)
?>


<?php
	/* array_diff_key() : 
		The array_diff_key() function compares two or more arrays, and returns an array with the keys and values from the first array, only if the key is not present in any of the other arrays.
	*/
	$a1=array(0=>"Cat",1=>"Dog",2=>"Horse");
	$a2=array(2=>"Bird",3=>"Rat",4=>"Fish");
	$a3=array(5=>"Horse",6=>"Dog",7=>"Bird");
	print_r(array_diff_key($a1,$a2,$a3));

	// Output = Array ( [0] => Cat, [1] => Dog )
?>


<?php		
	/* array_fill() :
		The array_fill() function returns an array filled with the values you describe.
	*/
	$a = array_fill(5,3,'banana');
	print_r($a);

	//Ouput = Array( [5]  => banana, [6]  => banana,[7]  => banana)

?>	


<?php
	/* array_flip() : 
		The array_flip() function returns an array with all the original keys as values, and all original values as keys.
	*/

	$a=array(0=>"Dog",1=>"Cat",2=>"Horse");
	print_r(array_flip($a));

	//Ouput = Array ( [Dog] => 0 [Cat] => 1 [Horse] => 2 )
?>

<?php
	/* array_push() : 
		The array_push() function inserts one or more elements to the end of an array.
	*/

	$a=array("Dog","Cat");
	array_push($a,"Horse","Bird");
	print_r($a);

	//Output = Array ( [0] => Dog [1] => Cat [2] => Horse [3] => Bird )
?>

<?php
	/* array_pop() :
		The array_pop() function deletes the last element of an array.
	*/

	$a=array("Dog","Cat","Horse");
	array_pop($a);
	print_r($a);

	//Output = Array ( [0] => Dog [1] => Cat )
?>

<?php
 	/* array_shift() :
 		The array_shift() function removes the first element from an array, and returns the value of the removed element.
 	*/

	$a=array(0=>"Dog",1=>"Cat",2=>"Horse");
	echo array_shift($a);
	print_r ($a);

	//Output = Array ( [b] => Cat [c] => Horse )
?>

<?php
	/* array_unshift() : 
		The array_unshift() function inserts new elements to an array. The new array values will be inserted in the beginning of the array. The function's return value is the new number of elements in the array
	*/

	$a=array("a"=>"Cat","b"=>"Dog");
	array_unshift($a,"Horse");
	print_r($a);

	//Output = Array ( [0] => Horse [a] => Cat [b] => Dog )
?>

<?php
	/* array_merge() : 
		The array_merge() function merges one or more arrays into one array.
	*/

	$a1=array("a"=>"Horse","b"=>"Dog");
	$a2=array("c"=>"Cow","b"=>"Cat");
	print_r(array_merge($a1,$a2));

	//Output = Array ( [0] => Horse [1] => Dog )

?>


<?php
	/* array_reduce() :
		The array_reduce() function sends the values in an array to a user-defined function, and returns a string.
 
	*/

	function myfunction($v1,$v2){
		return $v1 . "-" . $v2;
	}

	$a=array("Dog","Cat","Horse");

	print_r(array_reduce($a,"myfunction"));

	//Output = Dog-Cat-Horse
?>

<?php
	/* array_search() : 
		The array_search() function search an array for a value and returns the key.
	*/

	$array = array('red','blue','green','yellow');

	$key = array_search('green', $array);
	echo $key;

	//Output = 2
?>
