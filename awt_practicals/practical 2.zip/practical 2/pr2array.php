<?php

echo "<h1> Basics About Array </h1>";
echo "</br> <hr>";
echo "<h3> Numeric Array </h3>";

$n = array ('PHP','Laravel','Zend');
print_r($n);

echo "<h3> Associative Array </h3>";

$n = array ('PHP'=>'Vatsal','Laravel'=>'Vador','Zend'=>'Valsad');
print_r($n);

echo "<h3> Multi dimeltional Array </h3>";

$n = array ("CE"=>array("Vatsal","Vador"),"IT"=>array("Yogesh"),"Vador");
print_r($n);

echo "<h3> Type Casting and overwriting example </h3>";

$n = array (1=>"a","1"=>"b",1.5=>"c",true=>"d");
var_dump($n);

echo "<h3> Mixed integer and string keys </h3>";
$n = array("foo"=>"bar","bar"=>"foo",100=>-100,-100=>100);
var_dump($n);

echo "<h3> Key not on all element </h3>";
$n = array("a","b",6=>"c","d");
var_dump($n);

echo "<h1> Array Functions </h1>"."</br> <h3> array_value() </h3>";
$arr = array(5=>1,12=>2);
$arr[]=56; // this is the same as $arr[13]=56;

$arr["x"]=42; // this adds new element with key x

print_r($arr);
echo "</br>";

unset($arr[5]); // this removes element from array but array won't be re-indexed
print_r($arr);

echo "</br>";
unset($arr); // this deletes the whole array

echo "</br>";
$array = array(1,2,3,4,5);
print_r($array);

foreach ($array as $key => $value) {
	unset($array[$key]);
}

echo "</br>";
print_r($array);

echo "</br>";
$array[]=6; // this new inserted item will be at position 6, no re-indexing
print_r($array);

echo "</br>";
$array = array_values($array); // used for re-indexing : array_values($array_name);
$array[]=7; // adding new element after re-indexing
print_r($array);

echo "</br>"."<h3> array_change_key_case() </h3> "."</br>";

$a = array("a"=>"Cat","b"=>"Dog","c"=>"Horse","B"=>"AADIMANAV");
print_r(array_change_key_case($a,CASE_UPPER));

echo "</br>"."<h3> array_chunk() </h3> "."</br>";
$a = array("a"=>"Cat","b"=>"Dog","c"=>"Horse","d"=>"Cow");
var_dump(array_chunk($a,2));

echo "</br>"."<h3> array_combine() </h3> "."</br>";
$a1 = array("a","b","c","d");
$a2 = array("Cat","Dog","Horse","Cow");
print_r(array_combine($a1,$a2));

echo "</br>"."<h3> implode() </h3> "."</br>";
$arr = array('Hello','World!','Day!');
echo implode(" ",$arr);

echo "</br>"."<h3> explode() </h3> "."</br>";
$str = "Hello world. It's a beautiful day.";
print_r(explode(" ",$str));

echo "</br>"."<h3> array_count_values() </h3> "."</br>";
$array = array(1,"hello",1,"world","hello");
print_r(array_count_values($array));

echo "</br>"."<h3> array_diff() </h3> "."</br>";
$array1 = array("a"=>"green","red","blue","red");
$array2 = array("b"=>"green","yellow","red");
$result = array_diff($array1,$array2);
print_r($result);

echo "</br>"."<h3> array_diff_assoc() </h3> "."</br>";
$array1 = array("a"=>"green","b"=>"brown","c"=>"blue","red");
$array2 = array("a"=>"green","yellow","red");
$result = array_diff_assoc($array1,$array2);
print_r($result);

echo "</br>"."<h3> array_diff_key() </h3> "."</br>";
$array1 = array(0=>"Cat",1=>"Dog",2=>"Horse");
$array2 = array(2=>"Bird",3=>"Rat",4=>"Fish");
$array3 = array(5=>"Horse",6=>"Dog",7=>"Bird");
print_r(array_diff_key($array1,$array2,$array3));

echo "</br>"."<h3> array_fill() </h3> "."</br>";
$a = array_fill(5,6,'banana');
$b = array_fill(-2,4,'pear');
print_r($a); echo "</br>";
print_r($b);

echo "</br>"."<h3> array_flip() </h3> "."</br>";
$a = array(0=>"Dog",1=>"Cat",2=>"Horse");
print_r(array_flip($a));

echo "</br>"."<h3> array_filter() </h3> "."</br>";
function odd($var)
{
	return($var & 1);
}

function even($var)
{
	return(!($var & 1));
}

$array1 = array("a"=>1,"b"=>2,"c"=>3,"d"=>4,"e"=>5);
$array2 = array(6,7,8,9,10,11,12);

echo "Odd :";
print_r(array_filter($array1,"odd"));

echo "</br>";

echo "Even :";
print_r(array_filter($array2,"even"));

echo "</br>"."<h3> array_intersect_assoc() </h3> "."</br>";
$array1 = array("a"=>"green","b"=>"brown","c"=>"blue","red");
$array2 = array("a"=>"green","b"=>"yellow","blue","red");
$result = array_intersect_assoc($array1,$array2);
print_r($result);

echo "</br>"."<h3> array_key_exists() </h3> "."</br>";
$a = array("Dog","Cat");
if ( array_key_exists(0,$a))
{
	echo "Key exists !";
}
else
{
	echo "Key does not exists !";
}

echo "</br>"."<h3> array_key() </h3> "."</br>";
$a = array("a"=>"Horse","b"=>"Dog","c"=>"Cat");
print_r(array_keys($a,"Cat"));

echo "</br>"."<h3> array_push() </h3> "."</br>";
$a = array("a"=>"Dog","b"=>"Cat");
array_push($a,"Horse","Bird");
print_r($a);

echo "</br>"."<h3> array_pop() </h3> "."</br>";
$a = array("Dog","Cat","Horse");
array_pop($a);
print_r($a);

echo "</br>"."<h3> array_shift() </h3> "."</br>";
$array1 = array("a"=>"green","b"=>"brown","c"=>"blue");
echo array_shift($array1)."</br>";
print_r($array1);

echo "</br>"."<h3> array_unshift() </h3> "."</br>";
$array1 = array("a"=>"green","b"=>"brown","c"=>"blue");
echo array_unshift($array1,"Horse")."</br>";
print_r($array1);

echo "</br>"."<h3> array_map() </h3> "."</br>";
function myfunction($v)
{
	if($v==="Dog")
	{
		return "Fido";
	}
	return $v;
}

$a = array("Horse","Dog","Cat");
print_r(array_map("myfunction",$a));

echo "</br>"."<h3> array_merge() </h3> "."</br>";
$a = array("a"=>"Dog","b"=>"Cat");
$b = array("c"=>"Cow","b"=>"Cat");
print_r(array_merge($a,$b));

echo "</br>"."<h3> array_merge_recursive() </h3> "."</br>";
$a = array("a"=>"Dog","b"=>"Cat");
$b = array("c"=>"Cow","b"=>"Cat");
print_r(array_merge_recursive($a,$b));

echo "</br>"."<h3> array_reduce() </h3> "."</br>";
function ffunction($v1,$v2)
{
	return $v1 . "-" . $v2;
}

$a = array("Dog","Cat","Horse");
print_r(array_reduce($a,"ffunction"));

echo "</br>"."<h3> array_search() </h3> "."</br>";
$array = array('blue','red','green','red');
$key = array_search('green',$array); // $key = 2;
echo "Key : "."$key";

echo "</br>"."<h3> array_walk() </h3> "."</br>";
function gfunction($value,$key,$p)
{
	echo "$key $p $value</br>";
}
$a = array("a"=>"Cat","b"=>"Dog","c"=>"Horse");
array_walk($a,"gfunction","has the value");

echo "</br>"."<h3> array_walk() </h3> "."</br>";
function hfunction($value,$key)
{
	echo "$key $value</br>";
}
$a1 = array("a"=>"Cat","b"=>"Dog");
$a2 = array($a1,"1"=>"Bird","2"=>"Horse");
array_walk_recursive($a2,"hfunction");
?>