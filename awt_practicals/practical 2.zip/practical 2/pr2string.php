<?php

echo "<h3> addcslashes() </h3>";
$str = "Hello, my name is Kai Jim.";
echo $str."</br>";
echo addcslashes($str,'m')."</br>";
echo addcslashes($str,'k')."</br>";
echo addcslashes($str,'A..Z')."</br>";
echo addcslashes($str,'a..z')."</br>";
echo addcslashes($str,'a..h')."</br>";

echo "<h3> chunk_split() </h3>";
$str = "Hello world!";
echo chunk_split($str,1,".")."</br>";
echo chunk_split($str,6,"...");

echo "<h3> str_ireplace() </h3>";
echo str_ireplace("WORLD","Peter","Hello world!");

echo "<h3> str_pad() </h3>";
$str = "Hello world!";
echo str_pad($str,20,".")."</br>";
echo str_pad($str,20,".",STR_PAD_LEFT)."</br>";
echo str_pad($str,20,".",STR_PAD_BOTH);

echo "<h3> str_repeat() </h3>";
echo str_repeat(".",13);

echo "<h3> str_shuffle() </h3>";
echo str_shuffle("Hello World");

echo "<h3> str_split() </h3>";
print_r(str_split("Hello"));
echo "</br>";
print_r(str_split("Hello",3));

echo "<h3> str_word_count() </h3>";
echo str_word_count("Hello World !");
print_r(str_word_count("Hello World !",1));echo "</br>";
print_r(str_word_count("Hello World !",2));echo "</br>";
print_r(str_word_count("Hello World & good morning!",1));echo "</br>";
print_r(str_word_count("Hello World & good morning!",1,"&"));echo "</br>";

echo "<h3> strcasecmp() </h3>";
echo strcasecmp("Hello world!","HELLO WORLD!");

echo "<h3> strcmp() </h3>";
echo strcmp("Hello world!","Hello world!");

echo "<h3> stripcslashes() </h3>";
echo stripcslashes("Hello, \my na\me is Vatsa\l.");

echo "<h3> strpbrk() </h3>";
echo strpbrk("Hello world!","oe");

echo "<h3> strpos() </h3>";
echo strpos("Hello world!","wo");

echo "<h3> strstr() </h3>";
echo strstr("Hello world!","world");

echo "<h3> strtok() </h3>";
$string = "Hello world. Beautiful day today.";
$token = strtok($string," ");
while ($token != false)
{
	echo "$token</br>";
	$token = strtok(" ");
}

echo "<h3> substr() </h3>";
echo substr("Hello world!",6,5);

echo "<h3> substr_compare() </h3>";
echo substr_compare("Hello world","WORLD",6,TRUE);

echo "<h3> substr_count() </h3>";
echo substr_count("Hello world. The world is nice","world");
?>