<style> body{ font-size: 20px; font-weight: bold;} </style>
<?php
	
	// All Functions
	function connect_to_db($host, $username, $password){
		try{
			// Create connection
			$connection = mysqli_connect($host, $username, $password);
			echo "Database Connetion Established successfully !"."<hr>";
			return $connection;
		}catch(mysqli_sql_exception $e){
			die("Connection failed: " . mysqli_connect_error());
		}
	}
	
	function db_query($connection,$query){
		        if($result = mysqli_query($connection, $query)){
		        	return $result;
		        }else{
		        	echo "Query Failed ! @query : ". $query."<br>";
		        	return false;
		        }
	}

	function fetch_result($resultset){
		if(!$resultset){
			while($set = mysqli_fetch_assoc($resultset) ){
				$ans[] = $set; 
			}
			return $ans;
		}else{
			return false;
		}
	}

	function print_table($resultset){
		echo "<style>table, th, td { border: 1px solid black;border-collapse: collapse;}</style> ";
		echo "<table>";
		echo "<tr><th>Name</th><th>Password</th></tr>";
		while($row = mysqli_fetch_assoc($resultset)){
			echo "<tr>";
			echo "<td>".$row['username']."</td>";
			echo "<td>".$row['hashed_password']."</td>";
			echo "</tr>";
		}
		echo "</table>";
	}


/*
 *	a) Create database if not exists
 *	b) Create Table with auto increment id and necessary constraints.
 *	c) Add records in respective Table of database.
 *	d) Update and delete records.
 *	e) Retrieve all records or apply specific filter to display records from table.
 */

	//Connecting to database
	$con = connect_to_db("localhost","root","root");

	db_query($con,"DROP DATABASE sample_db");

	// a. Create database if not exists
		$sql = " CREATE DATABASE IF NOT EXISTS sample_db;";
		$resultObj = db_query($con,$sql);
		$result = fetch_result($resultObj);
		
		echo !$result ? "Database Created !" : "Database Creation Failed !";
		echo "<hr>";

		db_query($con,"USE sample_db;");


	//b. Create table with auto increment id and necessary constraints
		$sql = "CREATE TABLE IF NOT EXISTS user ( id int(11) NOT NULL AUTO_INCREMENT, username varchar(45) NOT NULL, hashed_password varchar(45) NOT NULL, PRIMARY KEY(id) );";
		$resultObj = db_query($con,$sql);
		$result = fetch_result($resultObj);

		echo !$result ? "Table Created !" : "Table Creation Failed !";
		echo "<hr>";


	//c. Add records in respective Table of database
		$sql = "INSERT INTO user(username,hashed_password) VALUES('KKSR1','KKSR1'),('KKSR2','KKSR2'),('KKSR3','KKSR3'); ";
		$resultObj = db_query($con,$sql);
		$result = fetch_result($resultObj);

		echo !$result ? "Records Inserted !" : "Records Insertion Fail !";
		echo "<hr>";


	//d. Update values 
		$sql = "UPDATE user SET username='KARAN' WHERE id=1;";
		$resultObj = db_query($con,$sql);
		$result = fetch_result($resultObj);

		echo !$result ? "Table Updated !" : "Table Updation Fail !";
		echo "<hr>";

	// Delete Records
		$sql = "DELETE FROM user WHERE id=3;";
		$resultObj = db_query($con,$sql);
		$result = fetch_result($resultObj);

		echo !$result ? "Row Deleted !" : "Row Deletion Fail !";
		echo "<hr>";

	// e. Retrieve All records
		$sql = "SELECT * FROM user";
		$resultObj = db_query($con,$sql);
		echo "User Table : <br>";
		print_table($resultObj);


?>